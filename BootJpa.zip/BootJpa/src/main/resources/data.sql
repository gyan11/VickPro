insert into alien values(101,'Gyan','CSE');
insert into alien values(102,'babar','Pak');
insert into alien values(103,'ramesj','Art');
insert into alien values(104,'Pinky','hindi');
insert into alien values(107,'Ravi','CPP');